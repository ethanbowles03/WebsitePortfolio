#include "confetti.h"
#include <QPainter>
#include <QDebug>
#include <iostream>
#include <random>

/**
 * @brief Confetti object for the correct answer animation.
 * @param parent
 */
Confetti::Confetti(QWidget *parent) : QWidget(parent),
    world(b2Vec2(0.0f, 0.0f)),
    timer(this),
    blueConfetti(":/resources/resources/blueConfetti.png"),
    purpleConfetti(":/resources/resources/purpleConfetti.png"),
    greenConfetti(":/resources/resources/greenConfetti.png")
{
    // Scale the images
    blueConfetti = blueConfetti.scaled(6, 12);
    purpleConfetti = purpleConfetti.scaled(6, 12);
    greenConfetti = greenConfetti.scaled(6, 12);

    // Allows for the user to click things underneath the widget
    setAttribute(Qt::WA_TransparentForMouseEvents);

    // Everytime the timer timesout, the world updates
    connect(&timer, &QTimer::timeout, this, &Confetti::updateWorld);
}

/**
 * @brief Starts the confetti animation
 */
void Confetti::startConfetti() {
    // Define a shape for the confetti pieces
    b2PolygonShape shape;
    shape.SetAsBox(0.1f, 0.1f); // small rectangle shape

    // Create a set of confetti pieces and add them to the world
    const int numConfetti = 100;
    for (int i = 0; i < numConfetti; i++) {
        b2BodyDef bodyDef;
        bodyDef.type = b2_dynamicBody;
        bodyDef.position.Set(30.0f, 15.0f); // initial position
        confetti.append(world.CreateBody(&bodyDef));

        b2FixtureDef fixtureDef;
        fixtureDef.shape = &shape;
        fixtureDef.density = 1.0f;
        confetti[i]->CreateFixture(&fixtureDef);
    }

    // Sets up random generation
    std::default_random_engine engine;
    std::uniform_real_distribution<float> angleRange(-1.0f, 1.0f);
    std::uniform_real_distribution<float> strengthRange(2.0f, 4.0f);
    std::uniform_real_distribution<float> torqueRange(-0.2f, 0.2f);

    // Apply a random impulse and torque to each confetti piece in a random direction
    for (int i = 0; i < numConfetti; i++) {
        // Generate random numbers
        b2Vec2 randomDirection = b2Vec2(angleRange(engine), angleRange(engine));
        float randomStrength = strengthRange(engine);
        float randomTorque = torqueRange(engine);

        // Apply the impulse and torque
        b2Vec2 impulse(randomDirection.x * randomStrength, randomDirection.y * randomStrength);
        confetti[i]->ApplyLinearImpulse(impulse, confetti[i]->GetWorldCenter(), true);
        confetti[i]->ApplyAngularImpulse(randomTorque, true);
    }

    timer.start(10);
}

/**
 * @brief Paints all of the confetti in the world. Called from updateWorld()
 */
void Confetti::paintEvent(QPaintEvent *) {
    // Create a painter
    QPainter painter(this);

    // Paint all confetti
    for(int i = 0; i < confetti.size(); i++) {
        b2Vec2 position = confetti[i]->GetPosition();
        float angle = confetti[i]->GetAngle();

        // Translate the painter to the center of the confetti body
        painter.translate(position.x*20, position.y*20);

        // Rotate the painter by the angle of the confetti body
        painter.rotate(angle * 180 / M_PI);

        // Choose the color of the confetti and draw it
        int color = i % 3;
        switch (color) {
            case 0:
                painter.drawImage(-blueConfetti.width() / 2, -blueConfetti.height() / 2, blueConfetti);
            break;
            case 1:
                painter.drawImage(-purpleConfetti.width() / 2, -purpleConfetti.height() / 2, purpleConfetti);
            break;
            case 2:
                painter.drawImage(-greenConfetti.width() / 2, -greenConfetti.height() / 2, greenConfetti);
            break;
        }

        // Reset the painter's transform
        painter.resetTransform();
    }

    painter.end();
}

/**
 * @brief Called everytime the timer timesout.
 */
void Confetti::updateWorld() {
    static float elapsedTime = 0.0f;  // elapsed time since simulation started
    elapsedTime += 1.0f/60.0f;  // increase elapsed time by the time step

    // Step the world simulation
    world.Step(1.0f/60.0f, 6, 2);

    // Check if 2 seconds have passed
    if (elapsedTime >= 2.0f) {
        timer.stop();  // stop the timer
        world.ClearForces();  // clear the forces in the world
        for (b2Body* body = world.GetBodyList(); body != nullptr; body = body->GetNext()) {
            world.DestroyBody(body);  // destroy all bodies in the world
        }
        confetti.clear();
        elapsedTime = 0.0f;
    }

    update();  // update the display
}
