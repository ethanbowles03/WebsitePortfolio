#include "mainmodel.h"
#include <QFile>
#include <QDebug>
#include <iostream>

/**
 * @brief Constructor
 */
MainModel::MainModel() {
    //Section order
    sections.push_back("Home");
    sections.push_back("InsertLearn");
    sections.push_back("MergeLearn");
    sections.push_back("QuickLearn");
    sections.push_back("InsertPrac");
    sections.push_back("MergePrac");
    sections.push_back("QuickPrac");
    sections.push_back("Review");

    //Access order
    access.push_back("Home");
    access.push_back("InsertLearn");
    access.push_back("InsertPrac");
    access.push_back("MergeLearn");
    access.push_back("MergePrac");
    access.push_back("QuickLearn");
    access.push_back("QuickPrac");
    access.push_back("Review");
}

/**
 * @brief MainModel::getCompletion - gets the completion of the program
 * @return
 */
int MainModel::getCompletion(){
    return userCompletion;
}

/**
 * @brief called when ever a section is updated
 *
 * @param sectionName - the name of the section to switch to
 */
void MainModel::onUpdateSection(std::string sectionName) {
    //Get Section Value
    for(int i = 0; i < sections.size(); i++) {
        if(sectionName == sections.at(i)) {
            currentSection = i;
            break;
        }
    }

    //Gets access value
    for(int i = 0; i < access.size(); i++) {
        if(sectionName == access.at(i)) {
            currentAccess = i;
            break;
        }
    }

    emit sendSection(currentSection);
}

/**
 * @brief MainModel::onUpdateAccess - emits the progress bar updates and activates buttons
 */
void MainModel::onUpdateAccess(){
    //Update progress bar
    if(currentAccess > userCompletion){
        userCompletion++;
        emit sendProgressBar(userCompletion);
    }

    if(userCompletion == 1){emit turnOnInsertPractice("Start"); emit enableInsertPractice(true);}
    if(userCompletion == 2){emit turnOnMergeLearn("Start"); emit enableMergeLearn(true);}
    if(userCompletion == 3){emit turnOnMergePractice("Start"); emit enableMergePractice(true);}
    if(userCompletion == 4){emit turnOnQuickLearn("Start"); emit enableQuickLearn(true);}
    if(userCompletion == 5){emit turnOnQuickPractice("Start"); emit enableQuickPractice(true);}
    if(userCompletion == 6){emit turnOnReview("Start"); emit enableReview(true);}
}

