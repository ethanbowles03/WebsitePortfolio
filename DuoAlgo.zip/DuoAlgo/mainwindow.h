
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "QtWidgets/qpushbutton.h"
#include "mainmodel.h"
#include <QMainWindow>

#include <string>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow

{
    Q_OBJECT

public:
    MainWindow(MainModel& model, QWidget *parent = nullptr);
    ~MainWindow();

private:
    /**
     * @brief setupSectionWidgets
     * @param model
     */
    void setupSectionWidgets(MainModel &model);

    /**
     * @brief progressUpdated
     * @param value
     */
    void progressUpdated(int value);

    /**
     * @brief chooseSection
     * @param section
     */
    void chooseSection(int section);

    /**
     * @brief updatePastSection
     * @param section
     */
    void updatePastSection(int section);

    void homeButtonClicked();

    void updateProgressBar(int progress);

    void receiveErrorMessage(std::string message);

    Ui::MainWindow *ui;
    QPushButton *homeButton;
};

#endif // MAINWINDOW_H
