#ifndef QUICKPRACTICE_H
#define QUICKPRACTICE_H

#include "mainmodel.h"
#include <QWidget>
#include <QListWidget>

namespace Ui {
class QuickPractice;
}

class QuickPractice : public QWidget
{
    Q_OBJECT

public:
    explicit QuickPractice(MainModel &model, QWidget *parent = nullptr);
    ~QuickPractice();

private:
    Ui::QuickPractice *ui;
    QVector<QVector<int>> steps;
    void setState(int state[]);
    void CheckSolution();
    void EnableCheckButton();
    void SetUpNextStep();
    void ContinueCurrentStep();
    void DisplayComplete();
    void highlightSelector(int oldPivot, int newPivot);

    int stepCounter;

signals:
    /**
     * @brief Sends a bool value on whether or not the user was correct.
     * @param val
     */
    void resultOfCheck(bool val);
    void stepComplete();
    void stepIncomplete();
    void orderingComplete();
    void complete();
};

#endif // QUICKPRACTICE_H
