#ifndef INSERTIONLEARN_H
#define INSERTIONLEARN_H

#include "mainmodel.h"
#include <QWidget>

namespace Ui {
class InsertionLearn;
}

class InsertionLearn : public QWidget
{
    Q_OBJECT

public:
    explicit InsertionLearn(MainModel &model, QWidget *parent = nullptr);
    ~InsertionLearn();

private:
    Ui::InsertionLearn *ui;

};

#endif // INSERTIONLEARN_H
