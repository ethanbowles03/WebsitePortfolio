#ifndef INSERTIONPRACTICE_H
#define INSERTIONPRACTICE_H

#include "mainmodel.h"
#include <QWidget>
#include <QListWidget>

namespace Ui {
class InsertionPractice;
}

class InsertionPractice : public QWidget
{
    Q_OBJECT

public:
    explicit InsertionPractice(MainModel &model, QWidget *parent = nullptr);
    ~InsertionPractice();

private:
    Ui::InsertionPractice *ui;
    QVector<QVector<int>> steps;
    void setState(int state[]);
    void CheckSolution();
    void EnableCheckButton();
    void SetUpNextStep();
    void ContinueCurrentStep();
    void DisplayComplete();

    int stepCounter;

signals:
    /**
     * @brief Sends a bool value on whether or not the user was correct.
     * @param val
     */
    void resultOfCheck(bool val);
    void stepComplete();
    void stepIncomplete();
    void orderingComplete();
    void complete();
};

#endif // INSERTIONPRACTICE_H
