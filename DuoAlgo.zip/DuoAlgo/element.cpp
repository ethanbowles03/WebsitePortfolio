#include "element.h"
#include "ui_element.h"

/**
 * @brief Element::Element - creates an element with a specified number to display
 * @param parent - the parent of the element
 * @param display - the number to display
 */
Element::Element(QWidget *parent, int display) :
    QWidget(parent),
    ui(new Ui::Element)
{
    ui->setupUi(this);

    // Set number to display
    ui->element->setText(QString::number(display));
    ui->element->setAlignment(Qt::AlignCenter);
    number = display;

    // By default will not be highlighted
    removeHighlight();
}

Element::~Element()
{
    delete ui;
}

/**
 * @brief Sets the styling for a highlighted element.
 */
void Element::highlight() {
    QString css = "background-color: #fff; color: #235490; border-radius: 15px; font-size: 50px;";
    ui->element->setStyleSheet(css);
    //TODO: Set font in css string
}

/**
 * @brief Sets the styling for a non-highlighted element.
 */
void Element::removeHighlight() {
    QString css = "background-color: #235490; color: #fff; border-radius: 15px; font-size: 50px;";
    ui->element->setStyleSheet(css);
    //TODO: Set font in css string
}
