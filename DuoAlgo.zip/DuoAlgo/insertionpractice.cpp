#include "insertionpractice.h"
#include "ui_insertionpractice.h"
#include "element.h"
#include <iostream>

/**
 * @brief Initializes the insertion practice section.
 * @param model
 * @param parent
 */
InsertionPractice::InsertionPractice(MainModel &model, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::InsertionPractice)
{
    ui->setupUi(this);
    ui->checkButton->setDisabled(true);
    ui->correctLabel->hide();
    ui->incorrectLabel->hide();
    ui->finishedLabel->hide();

    connect(ui->listWidget, &QListWidget::itemPressed, this, &InsertionPractice::EnableCheckButton);
    connect(ui->checkButton, &QPushButton::clicked, this, &InsertionPractice::CheckSolution);
    connect(this, &InsertionPractice::stepComplete, this, &InsertionPractice::SetUpNextStep);
    connect(this, &InsertionPractice::stepIncomplete, this, &InsertionPractice::ContinueCurrentStep);
    connect(this, &InsertionPractice::orderingComplete, this, &InsertionPractice::DisplayComplete);
    connect(this, &InsertionPractice::complete, &model, &MainModel::onUpdateAccess);

    // Starting-state of the elements
    int start[10] = {1, 7, 3, 5, 4, 6, 8, 9, 2, 0};
    setState(start);
    stepCounter = 0;
}

/**
 * @brief InsertionPractice destructor.
 */
InsertionPractice::~InsertionPractice()
{
    delete ui;
}

/**
 * @brief Sets the state of the elements in the list
 * @param state - an array that describes the state of the elements in order
 */
void InsertionPractice::setState(int state[]){
    // Clear out the list
    while(ui->listWidget->count() > 0) {
        ui->listWidget->takeItem(0);
    }

    // Generate all of the elements and store in temp vector
    QVector<Element*> temp;
    for(int i = 0; i < 10; i++) {
        Element* e = new Element(this, i);
        temp.append(e);
    }

    // Get the size of elements
    Element e;
    QSize elementSize(e.width(), e.height());

    // Add in each element to the correct index
    for(int i = 0; i < 10; i++) {
        // Create a new item to pair with the widget
        QListWidgetItem* item = new QListWidgetItem();
        item->setSizeHint(elementSize);

        // Translate the current index to "shuffle" the elements according to the start array
        int index = state[i];
        Element* e = temp[index];

        // Add the item-widget pair to the list
        ui->listWidget->addItem(item);
        ui->listWidget->setItemWidget(item, e);
    }
}

/**
 * @brief Enables check button
 */
void InsertionPractice::EnableCheckButton(){
    ui->correctLabel->hide();
    ui->incorrectLabel->hide();
    ui->checkButton->setEnabled(true);
}

/**
 * @brief Checkes to make sure the user's order is correct in the exercise.
 */
void InsertionPractice::CheckSolution(){
    int currentOrder[10];
    //populates currentOrder list
    for(int i = 0; i < 10; i++) {
        QListWidgetItem* item = ui->listWidget->item(i);
        Element* e = dynamic_cast<Element*>(ui->listWidget->itemWidget(item));
        currentOrder[i] = e->number;
    }

    //creates lists checking for each step
    int step1[] = { 1, 3, 7, 5, 4, 6, 8, 9, 2, 0};
    int step2[] = { 1, 3, 5, 7, 4, 6, 8, 9, 2, 0};
    int step3[] = { 1, 3, 4, 5, 7, 6, 8, 9, 2, 0};
    int step4[] = { 1, 3, 4, 5, 6, 7, 8, 9, 2, 0};
    int step5[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
    int step6[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

    //assigns the step lists into a vector of lists
    std::vector checkList = {step1, step2, step3, step4, step5, step6};

    //if the currentOrder list is not in the correct order, emits stepIncomplete
    for(int i = 0; i < 10; i++){
        int checkInt = checkList[stepCounter][i];
        if (currentOrder[i] != checkList[stepCounter][i]){
            emit stepIncomplete();
            return;
        }
    }
    //if it is the final step, emits orderingComplete
    if (stepCounter == 5)
        emit orderingComplete();
    emit stepComplete();
}

/**
 * @brief After correctly finishing a step, sets the ui up for the next step
 */
void InsertionPractice::SetUpNextStep(){
    ui->correctLabel->show();
    ui->checkButton->setDisabled(true);
    stepCounter++;
}

/**
 * @brief After incorrectly attempting a step, sets the ui up to continue the current step
 */
void InsertionPractice::ContinueCurrentStep(){
    //creates lists checking for each step
    int step1[] = { 1, 3, 7, 5, 4, 6, 8, 9, 2, 0};
    int step2[] = { 1, 3, 5, 7, 4, 6, 8, 9, 2, 0};
    int step3[] = { 1, 3, 4, 5, 7, 6, 8, 9, 2, 0};
    int step4[] = { 1, 3, 4, 5, 6, 7, 8, 9, 2, 0};
    int step5[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
    int step6[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

    //assigns the step lists into a vector of lists
    std::vector checkList = {step1, step2, step3, step4, step5, step6};

    if(stepCounter > 0){
        setState(checkList[stepCounter - 1]);
    }else{
        setState(checkList[stepCounter]);
    }


    ui->incorrectLabel->show();
    ui->checkButton->setDisabled(true);
}

/**
 * @brief After correctly finishing the algorithm, disables ui forcing user to return to home
 */
void InsertionPractice::DisplayComplete(){
    ui->finishedLabel->show();
    ui->checkButton->setDisabled(true);
    ui->listWidget->setDisabled(true);
    emit complete();
}

