#ifndef QUICKLEARN_H
#define QUICKLEARN_H

#include "mainmodel.h"
#include <QWidget>

namespace Ui {
class QuickLearn;
}

class QuickLearn : public QWidget
{
    Q_OBJECT

public:
    explicit QuickLearn(MainModel &model, QWidget *parent = nullptr);
    ~QuickLearn();

private:
    Ui::QuickLearn *ui;
};

#endif // QUICKLEARN_H
