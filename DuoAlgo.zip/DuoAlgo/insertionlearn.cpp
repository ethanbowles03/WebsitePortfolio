#include "insertionlearn.h"
#include "ui_insertionlearn.h"

/**
 * @brief Initializes the insertion learn section.
 * @param model
 * @param parent
 */
InsertionLearn::InsertionLearn(MainModel &model, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::InsertionLearn)
{
    ui->setupUi(this);

    //Show the insertion sort graphic
    QPixmap image(":/resources/resources/insertionsort.png");
    image = image.scaled(500, 500, Qt::KeepAspectRatio);
    ui->graphicContainer->setPixmap(image);
    ui->textEdit->setStyleSheet(" QScrollBar{ background-color: none }");
}

/**
 * @brief InsertionLearn destructor
 */
InsertionLearn::~InsertionLearn()
{
    delete ui;
}
