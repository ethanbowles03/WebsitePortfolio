#include "navigationwindow.h"
#include "ui_navigationwindow.h"
#include <iostream>

/**
 * @brief NavigationWindow constructor
 * @param model
 * @param parent
 */
NavigationWindow::NavigationWindow(MainModel& model, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::NavigationWindow)
{
    //UI apperiance updates
    ui->setupUi(this);
    setUpButtons(model.getCompletion());
    ui->LearnLabel->setStyleSheet("background-color:rgb(35, 84, 144);");
    ui->LearnInsertLabel->setStyleSheet("background-color:rgb(35, 84, 144);");
    ui->LearnQuickLabel->setStyleSheet("background-color:rgb(35, 84, 144);");
    ui->LearnMergeLabel->setStyleSheet("background-color:rgb(35, 84, 144);");
    ui->PracMergeLabel->setStyleSheet("background-color:rgb(35, 84, 144);");
    ui->PracInsertLabel->setStyleSheet("background-color:rgb(35, 84, 144);");
    ui->PracQuickLabel->setStyleSheet("background-color:rgb(35, 84, 144);");
    ui->PracticeLabel->setStyleSheet("background-color:rgb(35, 84, 144);");
    ui->ReviewLabel->setStyleSheet("background-color:rgb(35, 84, 144);");
    ui->ReviewQuizLabel->setStyleSheet("background-color:rgb(35, 84, 144);");

    //Insert Connnects
    connect(ui->InsertLearn, &QPushButton::clicked, this, &NavigationWindow::updateSelection);
    connect(ui->InsertPrac, &QPushButton::clicked, this, &NavigationWindow::updateSelection);

    //Merge Connects
    connect(ui->MergeLearn, &QPushButton::clicked, this, &NavigationWindow::updateSelection);
    connect(ui->MergePrac, &QPushButton::clicked, this, &NavigationWindow::updateSelection);

    //Quick Connects
    connect(ui->QuickLearn, &QPushButton::clicked, this, &NavigationWindow::updateSelection);
    connect(ui->QuickPrac, &QPushButton::clicked, this, &NavigationWindow::updateSelection);

    // Quiz Connect
    connect(ui->Review, &QPushButton::clicked, this, &NavigationWindow::updateSelection);

    //Send selection and access
    connect(this, &NavigationWindow::sendSelection, &model, &MainModel::onUpdateSection);
    connect(this, &NavigationWindow::sendAccess, &model, &MainModel::onUpdateAccess);

    //Enable buttons
    connect(&model, &MainModel::enableInsertPractice, ui->InsertPrac, &QPushButton::setEnabled);
    connect(&model, &MainModel::enableMergeLearn, ui->MergeLearn, &QPushButton::setEnabled);
    connect(&model, &MainModel::enableMergePractice, ui->MergePrac, &QPushButton::setEnabled);
    connect(&model, &MainModel::enableQuickLearn, ui->QuickLearn, &QPushButton::setEnabled);
    connect(&model, &MainModel::enableQuickPractice, ui->QuickPrac, &QPushButton::setEnabled);
    connect(&model, &MainModel::enableReview, ui->Review, &QPushButton::setEnabled);

    // Display text on the buttons
    connect(&model, &MainModel::turnOnInsertPractice, ui->InsertPrac, &QPushButton::setText);
    connect(&model, &MainModel::turnOnMergeLearn, ui->MergeLearn, &QPushButton::setText);
    connect(&model, &MainModel::turnOnMergePractice, ui->MergePrac, &QPushButton::setText);
    connect(&model, &MainModel::turnOnQuickLearn, ui->QuickLearn, &QPushButton::setText);
    connect(&model, &MainModel::turnOnQuickPractice, ui->QuickPrac, &QPushButton::setText);
    connect(&model, &MainModel::turnOnReview, ui->Review, &QPushButton::setText);
}

/**
 * @brief NavigationWindow destructor - deletes the ui
 */
NavigationWindow::~NavigationWindow()
{
    delete ui;
}

/**
 * @brief NavigationWindow::updateSelection - sends the section to the model and the access
 */
void NavigationWindow::updateSelection(){
    //Get the section
    QPushButton* buttonClicked = qobject_cast<QPushButton*>(sender()); // retrieve the button you have clicked
    QString text = buttonClicked->objectName();
    selection = text.toStdString();

    //Send the section and emit the access if a learn section
    emit sendSelection(selection);
    if(selection == "InsertLearn" || selection == "MergeLearn" || selection == "QuickLearn"){emit sendAccess();}
}

/**
 * @brief NavigationWindow::setUpButtons - sets the states of the buttons depending on user progress
 * @param completion
 */
void NavigationWindow::setUpButtons(int completion){
    //Enable buttons based on access level
    if(completion >= 1){
        ui->InsertPrac->setEnabled(true);

        ui->InsertPrac->setText("Startaskdfl");
    }
    if(completion >= 2){
        ui->MergeLearn->setEnabled(true);
    }
    if(completion >= 3){
        ui->MergePrac->setEnabled(true);
    }
    if(completion >= 4){
        ui->QuickLearn->setEnabled(true);
    }
    if(completion >= 5){
        ui->QuickPrac->setEnabled(true);
    }
    if(completion >= 6){
        ui->Review->setEnabled(true);
    }
}
