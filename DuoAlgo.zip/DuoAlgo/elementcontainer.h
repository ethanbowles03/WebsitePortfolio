#ifndef ELEMENTCONTAINER_H
#define ELEMENTCONTAINER_H

#include <QLabel>
#include <QDropEvent>
#include <QMimeData>

namespace Ui {
/**
 * Class that represents an element to be used in the merge sort grid
 */
class ElementContainer;
}

class ElementContainer : public QLabel
{
    Q_OBJECT

public:
    /**
     * @brief ElementContainer - sets up the label
     * @param text - the text for the label
     * @param parent
     * @param f
     */
    ElementContainer(const QString &text, QWidget *parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());
    ~ElementContainer();

protected:
    /**
     * @brief dragEnterEvent - override the drag event
     * @param event
     */
    void dragEnterEvent(QDragEnterEvent *event) override;

    /**
     * @brief dropEvent - override the drop event
     * @param event
     */
    void dropEvent(QDropEvent *event) override;
};
#endif // ELEMENTCONTAINER_H
