
#include "mainwindow.h"
#include "mergelearn.h"
#include "navigationwindow.h"
#include "insertionlearn.h"
#include "insertionpractice.h"
#include "mergepractice.h"
#include "quicklearn.h"
#include "quickpractice.h"
#include "quiz.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <iostream>
#include <ostream>

/**
 * @brief Constructor
 * @param model
 * @param parent
 */
MainWindow::MainWindow(MainModel& model, QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //Widget and Home Setup
    setupSectionWidgets(model);
    homeButton = new QPushButton("Home", this);
    connect(homeButton, &QPushButton::clicked, this, &MainWindow::homeButtonClicked);
    homeButton->setGeometry(980, 15, 100, 50);
    homeButton->show();

    //Style
    setStyleSheet("background-color:rgb(35, 84, 144);");

    //Connections
    connect(&model, &MainModel::sendSection, this, &MainWindow::chooseSection);
    connect(&model, &MainModel::sendProgressBar, this, &MainWindow::updateProgressBar);
    connect(&model, &MainModel::sendErrorMessage, this, &MainWindow::receiveErrorMessage);
}

MainWindow::~MainWindow()
{
    delete ui;
}

/**
 * @brief MainWindow::setupSectionWidgets - Sets up all of the widgets and adds them to the stack
 * @param model - main model of window
 */
void MainWindow::setupSectionWidgets(MainModel &model){
    NavigationWindow *nw = new NavigationWindow(model);
    InsertionLearn *il = new InsertionLearn(model);
    InsertionPractice *ip = new InsertionPractice(model);
    MergeLearn *ml = new MergeLearn(model);
    MergePractice *mp = new MergePractice(model);
    QuickLearn *ql = new QuickLearn(model);
    QuickPractice *qp = new QuickPractice(model);
    Quiz *q = new Quiz(model);
    ui->navLayout->addWidget(nw);
    ui->navLayout->addWidget(il);
    ui->navLayout->addWidget(ml);
    ui->navLayout->addWidget(ql);
    ui->navLayout->addWidget(ip);
    ui->navLayout->addWidget(mp);
    ui->navLayout->addWidget(qp);
    ui->navLayout->addWidget(q);

    //Setup progress bar
   updateProgressBar(model.getCompletion());
}

/**
 * @brief MainWindow::progressUpdated - updates the progress bar when work completed
 * @param value
 */
void MainWindow::progressUpdated(int value){
    std::string sValue = std::to_string(value) + "%";
    QString updatedVal(sValue.c_str());
    ui->percentLabel->setText(updatedVal);
}

/**
 * @brief MainWindow::chooseSection - upates and chooses the section
 * @param section
 */
void MainWindow::chooseSection(int section){
    ui->navLayout->setCurrentIndex(section);
    update();
}

void MainWindow::homeButtonClicked(){
    chooseSection(0);
}

void MainWindow::updateProgressBar(int progress){
    int p = (double)(progress/7.0) * 100.0;
    ui->progressBar->setValue(p);
    progressUpdated(p);
    update();
}

void MainWindow::receiveErrorMessage(std::string message) {
    QMessageBox::critical(this, "Error", QString::fromStdString(message));
}
