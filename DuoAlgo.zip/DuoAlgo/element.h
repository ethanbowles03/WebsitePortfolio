#ifndef ELEMENT_H
#define ELEMENT_H

#include <QWidget>

namespace Ui {
class Element;
}

class Element : public QWidget
{
    Q_OBJECT

public:
    explicit Element(QWidget *parent = nullptr, int display = 0);
    ~Element();

    // The number shown
    int number;

    // Sets highlight styling
    void highlight();

    // Sets non-highlight styling
    void removeHighlight();

private:
    Ui::Element *ui;
};

#endif // ELEMENT_H
