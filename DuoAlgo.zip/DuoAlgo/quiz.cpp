#include "quiz.h"
#include "mainmodel.h"
#include "ui_quiz.h"
#include <QFile>
#include <QTextStream>
#include <iostream>

/**
 * @brief Quiz constructor
 * @param model
 * @param parent
 */
Quiz::Quiz(MainModel &model, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Quiz)
{
    ui->setupUi(this);

    // Read in all of the questions
    questions = readQuizQuestionsFromFile(":/resources/resources/questions.txt");

    // Show first question
    displayQuestion(0);
    currentQuestionIndex = 0;

    // Setup progress bar
    ui->progressBar->setMinimum(0);
    ui->progressBar->setMaximum(10);
    ui->progressBar->setValue(0);

    // Connect answer buttons
    connect(ui->answer0, &QPushButton::clicked, this, [this]{ answerClicked(0); });
    connect(ui->answer1, &QPushButton::clicked, this, [this]{ answerClicked(1); });
    connect(ui->answer2, &QPushButton::clicked, this, [this]{ answerClicked(2); });
    connect(ui->answer3, &QPushButton::clicked, this, [this]{ answerClicked(3); });

    // Connect next button
    connect(ui->nextButton, &QPushButton::clicked, this, &Quiz::nextQuestion);

    // Connect completion of quiz
    connect(this, &Quiz::complete, &model, &MainModel::onUpdateAccess);
}

/**
 * @brief Quiz destructor
 */
Quiz::~Quiz()
{
    delete ui;
}

/**
 * @brief Creates a vector of quiz questions from a file.
 * @param filename - the path of the file
 * @return A QVector of quiz questions, answers, and correct answer index
 */
QVector<Quiz::QuizQuestion> Quiz::readQuizQuestionsFromFile(QString filename) {
    QVector<QuizQuestion> questions;

    // open the file for reading
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        // error opening file
        return questions;
    }

    // read the file line by line
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(',');

        // parse the line into a QuizQuestion object
        QuizQuestion question;
        question.question = parts[0].trimmed();
        for (int i = 1; i < 5; i++) {
            question.answers.push_back(parts[i].trimmed());
        }
        question.correctAnswerIndex = parts[5].toInt();

        questions.push_back(question);
    }

    file.close();
    return questions;
}

/**
 * @brief Updates the UI to show the specified question
 * @param index - the index of the specified question
 */
void Quiz::displayQuestion(int index) {
    // Get question struct
    QuizQuestion currentQuestion = questions[index];

    // Update ui
    ui->questionLabel->setText(currentQuestion.question);
    ui->answer0->setText(currentQuestion.answers[0]);
    ui->answer1->setText(currentQuestion.answers[1]);
    ui->answer2->setText(currentQuestion.answers[2]);
    ui->answer3->setText(currentQuestion.answers[3]);
    ui->feedbackLabel->setText(""); // Empty until user clicks an answer
    ui->nextButton->hide(); // Will be shown again when the user answers
}

/**
 * @brief Called when an answer is clicked. Checks the correctness of the user
 * @param answer - the number of the button clicked (0-3)
 */
void Quiz::answerClicked(int answer) {
    // Disable all the buttons
    ui->answer0->setEnabled(false);
    ui->answer1->setEnabled(false);
    ui->answer2->setEnabled(false);
    ui->answer3->setEnabled(false);

    // Get question struct
    QuizQuestion currentQuestion = questions[currentQuestionIndex];

    // Check correctness
    if(answer == currentQuestion.correctAnswerIndex) {
        // Correct
        ui->feedbackLabel->setText("Correct. Great job!");

        // Move to the next problem
        currentQuestionIndex++;

        // Confetti!!
        ui->confetti->startConfetti();
    }
    else {
        // Incorrect
        ui->feedbackLabel->setText("That's incorrect. The correct answer was " + currentQuestion.answers[currentQuestion.correctAnswerIndex] + ".");

        // Queue this problem for later
        questions.removeAt(currentQuestionIndex);
        questions.append(currentQuestion);
    }

    // Update UI
    changeButtonStylings(answer);
    ui->progressBar->setValue(currentQuestionIndex);

    // Show the next button if there are more questions
    if(currentQuestionIndex < questions.size()) {
        ui->nextButton->show();
    }else{
        emit complete();
    }
}

/**
 * @brief "Highlights" the button passed in and makes other buttons look disabled.
 *         Will also reset all buttons to default state if anything else is passed in.
 * @param button - The button number that should be highlighted.
 */
void Quiz::changeButtonStylings(int button) {
    switch(button) {
        case 0:
            ui->answer0->setStyleSheet(buttonStylingClicked);
            ui->answer1->setStyleSheet(buttonStylingDisabled);
            ui->answer2->setStyleSheet(buttonStylingDisabled);
            ui->answer3->setStyleSheet(buttonStylingDisabled);
            break;
        case 1:
            ui->answer0->setStyleSheet(buttonStylingDisabled);
            ui->answer1->setStyleSheet(buttonStylingClicked);
            ui->answer2->setStyleSheet(buttonStylingDisabled);
            ui->answer3->setStyleSheet(buttonStylingDisabled);
            break;
        case 2:
            ui->answer0->setStyleSheet(buttonStylingDisabled);
            ui->answer1->setStyleSheet(buttonStylingDisabled);
            ui->answer2->setStyleSheet(buttonStylingClicked);
            ui->answer3->setStyleSheet(buttonStylingDisabled);
            break;
        case 3:
            ui->answer0->setStyleSheet(buttonStylingDisabled);
            ui->answer1->setStyleSheet(buttonStylingDisabled);
            ui->answer2->setStyleSheet(buttonStylingDisabled);
            ui->answer3->setStyleSheet(buttonStylingClicked);
            break;
        default:
            ui->answer0->setStyleSheet(buttonStyling);
            ui->answer1->setStyleSheet(buttonStyling);
            ui->answer2->setStyleSheet(buttonStyling);
            ui->answer3->setStyleSheet(buttonStyling);
    }
}

/**
 * @brief Called when the next button is clicked. Shows the next question and updates UI.
 */
void Quiz::nextQuestion() {
    // Show new question
    displayQuestion(currentQuestionIndex);

    // Enable answer buttons and set styling
    ui->answer0->setEnabled(true);
    ui->answer1->setEnabled(true);
    ui->answer2->setEnabled(true);
    ui->answer3->setEnabled(true);
    changeButtonStylings(-1); // Resets buttons to default state
}
