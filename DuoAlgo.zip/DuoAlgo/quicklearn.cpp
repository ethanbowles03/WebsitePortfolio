#include "quicklearn.h"
#include "mainmodel.h"
#include "ui_quicklearn.h"

/**
 * @brief QuickLearn constructor.
 * @param model
 * @param parent
 */
QuickLearn::QuickLearn(MainModel &model, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QuickLearn)
{
    ui->setupUi(this);

    //Show the insertion sort graphic
    QPixmap image(":/resources/resources/quicksort.png");
    image = image.scaled(400, 400, Qt::KeepAspectRatio);
    ui->graphicContainer->setPixmap(image);
    ui->textEdit->setStyleSheet(" QScrollBar{ background-color: none }");
}

/**
 * @brief QuickLearn destructor
 */
QuickLearn::~QuickLearn()
{
    delete ui;
}
