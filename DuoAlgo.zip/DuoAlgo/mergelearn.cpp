#include "mergelearn.h"
#include "ui_mergelearn.h"

/**
 * @brief Constructor
 * @param model
 * @param parent
 */
MergeLearn::MergeLearn(MainModel &model, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MergeLearn)
{
    ui->setupUi(this);

    //Show the insertion sort graphic
    QPixmap image(":/resources/resources/mergesort.png");
    image = image.scaled(400, 400, Qt::KeepAspectRatio);
    ui->graphicContainer->setPixmap(image);
    ui->textEdit->setStyleSheet(" QScrollBar{ background-color: none }");
}

/**
 * @brief MergeLearn destructor
 */
MergeLearn::~MergeLearn()
{
    delete ui;
}
