#ifndef CONFETTI_H
#define CONFETTI_H

#include <QWidget>
#include <Box2D/Box2D.h>
#include <QTimer>

class Confetti : public QWidget
{
    Q_OBJECT
public:
    explicit Confetti(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    void startConfetti();

signals:

public slots:
    void updateWorld();

private:
    b2World world;
    QVector<b2Body*> confetti;
    QTimer timer;
    QImage blueConfetti;
    QImage purpleConfetti;
    QImage greenConfetti;
};

#endif // CONFETTI_H
