#ifndef MAINMODEL_H
#define MAINMODEL_H

#include <QObject>

#include <string>
#include <vector>

class MainModel : public QObject {
    Q_OBJECT
public:
    /**
     * @brief Constructor
     */
    MainModel();
    int getCompletion();

private:
    // holds all sections
    std::vector<std::string> sections;
    std::vector<std::string> access;

    // holds index of current active section
    int currentSection = 0;
    int currentAccess = 0;
    int userCompletion = 0;

public slots:
    /**
     * @brief called when ever a section is updated
     *
     * @param sectionName - the name of the section to switch to
     */
    void onUpdateSection(std::string sectionName);


    void onUpdateAccess();

signals:
    /**
     * @brief sendSection - sends the current section to the nav window
     * @param section - the section
     */
    void sendSection(int section);

    /**
     * @brief sendProgressBar - sends updates to the progress bar
     * @param progress - progress percent
     */
    void sendProgressBar(int progress);

    /**
     * @brief turnOnInsertPractice - turns on the insert practice section
     * @param on - state
     */
    void turnOnInsertPractice(QString on);

    /**
     * @brief turnOnMergeLearn - turns on the merge learn section
     * @param on - state
     */
    void turnOnMergeLearn(QString on);

    /**
     * @brief turnOnMergePractice - turns on the merge practice section
     * @param on - state
     */
    void turnOnMergePractice(QString on);

    /**
     * @brief turnOnQuickLearn - turns on the the quick learn section
     * @param on - state
     */
    void turnOnQuickLearn(QString on);

    /**
     * @brief turnOnQuickPractice - turns on the quick practice section
     * @param on - state
     */
    void turnOnQuickPractice(QString on);

    /**
     * @brief turnOnReview - turns on the review section
     * @param on - state
     */
    void turnOnReview(QString on);

    /**
     * @brief enableInsertPractice - enables the insertion practice section
     * @param enable
     */
    void enableInsertPractice(bool enable);

    /**
     * @brief enableMergeLearn - enables the merge learn section
     * @param enable
     */
    void enableMergeLearn(bool enable);

    /**
     * @brief enableMergePractice - enables the merge practice section
     * @param enable
     */
    void enableMergePractice(bool enable);

    /**
     * @brief enableQuickLearn - enables the quick learn section
     * @param enable
     */
    void enableQuickLearn(bool enable);

    /**
     * @brief enableQuickPractice - enables the quick practice section
     * @param enable
     */
    void enableQuickPractice(bool enable);

    /**
     * @brief enableReview - enables the review section
     * @param enable
     */
    void enableReview(bool enable);

    /**
     * @brief sendErrorMessage - sends an error message
     * @param message - the message
     */
    void sendErrorMessage(std::string message);
};

#endif // MAINMODEL_H
