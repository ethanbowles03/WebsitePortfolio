#ifndef MERGELEARN_H
#define MERGELEARN_H

#include "mainmodel.h"
#include <QWidget>

namespace Ui {
class MergeLearn;
}

class MergeLearn : public QWidget
{
    Q_OBJECT

public:
    explicit MergeLearn(MainModel &model, QWidget *parent = nullptr);
    ~MergeLearn();

private:
    Ui::MergeLearn *ui;
};

#endif // MERGELEARN_H
