#include "mergepractice.h"
#include "ui_mergepractice.h"
#include <QDrag>
#include <QMimeData>
#include "elementcontainer.h"

/**
 * @brief MergePractice constructor - sets up all ui, connections and timer
 * @param model - model to use for refrence and conncetions
 * @param parent
 */
MergePractice::MergePractice(MainModel &model, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MergePractice)
{
    ui->setupUi(this);
    QPixmap image(":/resources/resources/uparrow.png");
    image = image.scaled(50, 50, Qt::KeepAspectRatio);

    //UI apperiance setup
    ui->arrowContainter->setPixmap(image);
    ui->arrowContainter->setStyleSheet("background-color: rgba(0,0,0,0%)");
    ui->IncorrectPartitionLabel->setStyleSheet("QLabel { color : red; background-color: rgba(0,0,0,0%); }");
    ui->CorrectPartitionLabel->setStyleSheet("QLabel { background-color: rgba(0,0,0,0%); }");
    ui->IncorrectMergeLabel->setStyleSheet("QLabel { color : red; background-color: rgba(0,0,0,0%); }");
    ui->CorrectMergeLabel->setStyleSheet("QLabel { background-color: rgba(0,0,0,0%); }");
    ui->IncorrectPartitionLabel->setVisible(false);
    ui->CorrectPartitionLabel->setVisible(false);
    ui->IncorrectMergeLabel->setVisible(false);
    ui->CorrectMergeLabel->setVisible(false);
    ui->mergePhaseButton->setVisible(false);
    populateGrid();

    //Allows mouse tracking and starts
    setMouseTracking(true);
    mouseTimer = new QTimer(this);
    mouseTimer->setInterval(1);
    mouseTimer->start();

    //Connections
    connect(mouseTimer, &QTimer::timeout, this, &MergePractice::mouseUpdate);
    connect(ui->mergePhaseButton, &QPushButton::clicked, this, &MergePractice::startMergePhase);
    connect(this, &MergePractice::complete, &model, &MainModel::onUpdateAccess);
}

/**
 * @brief MergePractice destructor
 */
MergePractice::~MergePractice()
{
    delete mouseTimer;
    delete ui;
}

/**
 * @brief This method fills in the backing grid for the merge and partition phase
 * There are actually a lot of non visible objects in order to achieve the apperience
 */
void MergePractice::populateGrid(){
    //Valid elements are layed out
    int count = 1;
    bool validElements[4][16] = {{false, false, false, false, true, true, true, true, true, true, true, true, false, false, false, false},
                                {false, false, false, true, true, true, true, false, false, true, true, true, true, false, false, false},
                                {false, false, true, true, false, true, true, false, false, true, true, false, true, true, false, false},
                                {false, true, false, true, false, true, false, true, true, false, true, false, true, false, true, false}};

    //Loops through the partition array adding elements to the grid layout and setting their correct values
    for(int i = 0; i < 4; i++) {
        for(int j = 0; j < 16; j++){
            QLabel* element;
            if(validElements[i][j]){
                element = new QLabel(QString::number(backing[count - 1]));
                count++;
            }else{
                element = new QLabel;
            }
            element->setStyleSheet("QLabel { background-color : #5D7798; color : #5D7798;}");
            element->setAlignment(Qt::AlignCenter);
            ui->partitionGrid->addWidget(element, i, j);
            partList[i][j] = element;
        }
        count = 1;
    }

    //Loops through the merge array array adding elements to the grid layout and setting their correct values
    bool filling = true;
    for(int i = 3; i >= 0 ; i--) {
        for(int j = 15; j >= 0; j--){
            ElementContainer *cont;
            if(validElements[i][j] && filling){
                cont = new ElementContainer(QString::number(backing[count - 1]));
                cont->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px; ");
                count++;
            }else{
                cont = new ElementContainer("");
            }
            ui->mergeGrid->addWidget(cont,3-i,15-j);
            mergeList[3-i][15-j] = cont;
        }
        count = 1;
        filling = false;
    }

    //Sets the background color of the elements to start off in the partition section to be visible
    for(int i = 0; i < 16; i++) {
        if(i > 3 && i < 12){
            partList[0][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
        }
    }

    //Calls the merge phase once to get it started
    mergePhase();
    update();
}

/**
 * @brief MergePractice::mousePressEvent - activates a drag event when a label is clicked
 * @param event
 */
void MergePractice::mousePressEvent(QMouseEvent * event){
    //If not in the merge phase return
    if(!mergePhaseStarted){return;}

    //Gets the label under the mouse and makes a new drag
    QRect g = ui->mergeGrid->geometry();
    g.setRect(20,60,1061,455);
    if(g.contains(event->pos())){
        ElementContainer * label = qobject_cast<ElementContainer *>(childAt(event->pos()));
        QDrag *drag = new QDrag(this);
        QMimeData *mimeData = new QMimeData;
        if(label){
            mimeData->setText(label->text());
            drag->setMimeData(mimeData);
            drag->exec();
        }
    }
}

/**
 * @brief MergePractice::mouseReleaseEvent - when the mouse is release run the merge and partition methods
 * @param event
 */
void MergePractice::mouseReleaseEvent(QMouseEvent *event)
{
    //Remove incorrect label
    ui->IncorrectPartitionLabel->setVisible(false);

    //Run merge and partition logic
    mergePhase();
    partitionPhase();
    update();
}

/**
 * @brief MergePractice::mouseUpdate - gets the mouse position every milli second and sets the arrow to that location
 */
void MergePractice::mouseUpdate(){
    //Timer refresh
    mouseTimer->stop();
    mouseTimer->start();

    //If in merge phase remove arrow and call merge phase logic
    //If not merging update arrow position
    if(mergePhaseStarted){
        ui->arrowContainter->setGeometry(0,0,0,0);
        mergePhase();
    }else{
        QPoint mousePos = mapFromGlobal(QCursor::pos());
        mouseX = (((double)mousePos.x() - 25)/1100.0) * (1100/67);
        ui->arrowContainter->setGeometry((mouseX * 67) + 50 ,mouseY - 25,50,50);
    }
    update();
}

/**
 * @brief MergePractice::startMergePhase - changes the stackframe to the merge phase widgit
 */
void MergePractice::startMergePhase(){
    ui->stackedWidget->setCurrentIndex(1);
}

/**
 * @brief MergePractice::mergePhase - logic code for the merge phase. Shows all necicarry elements in the grid
 */
void MergePractice::mergePhase(){
    ui->IncorrectMergeLabel->setVisible(false);

    //If in the first stage of merging show correct places
    if(mergeProgress == 1){
        bool done = true;
        for(int i = 0; i < 16; i++) {
           if((i >= 2 && i <= 3) || (i >= 5 && i <= 6) || (i >= 9 && i <= 10) || (i >= 12 && i <= 13)){
               mergeList[1][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px; border-width: 5px; border-style: solid;");
               if(mergeList[1][i]->text().toStdString() == ""){done = false;}
           }
        }
        if(!done){return;}

        //Check that everything was places into the right box
        bool allCorrect = true;
        if(mergeList[1][2]->text().toInt() >= mergeList[1][3]->text().toInt()){allCorrect = false;}
        if(mergeList[1][5]->text().toInt() >= mergeList[1][6]->text().toInt()){allCorrect = false;}
        if(mergeList[1][9]->text().toInt() >= mergeList[1][10]->text().toInt()){allCorrect = false;}
        if(mergeList[1][12]->text().toInt() >= mergeList[1][13]->text().toInt()){allCorrect = false;}

        //If they are all correct un border every box
        if(allCorrect){
            mergeProgress++;
            for(int i = 0; i < 16; i++) {
               if((i >= 2 && i <= 3) || (i >= 5 && i <= 6) || (i >= 9 && i <= 10) || (i >= 12 && i <= 13)){
                   mergeList[1][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
               }
            }
        }else{//Display incorrect if wrong
            ui->IncorrectMergeLabel->setVisible(true);
        }
    }
    //If in the second stage of merging show correct places
    else if(mergeProgress == 2){
        bool done = true;
        for(int i = 0; i < 16; i++) {
           if((i >= 3 && i <= 6) || (i >= 9 && i <= 12)){
               mergeList[2][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px; border-width: 5px; border-style: solid;");
               if(mergeList[2][i]->text().toStdString() == ""){done = false;}
           }
        }
        if(!done){return;}

        //Checks that everything is put into the correct place
        bool allCorrect = true;
        if(mergeList[2][3]->text().toInt() >= mergeList[2][4]->text().toInt() ||
                mergeList[2][4]->text().toInt() >= mergeList[2][5]->text().toInt() ||
                mergeList[2][5]->text().toInt() >= mergeList[2][6]->text().toInt()){allCorrect = false;}
        if(mergeList[2][9]->text().toInt() >= mergeList[2][10]->text().toInt() ||
                mergeList[2][10]->text().toInt() >= mergeList[2][11]->text().toInt() ||
                mergeList[2][11]->text().toInt() >= mergeList[2][12]->text().toInt()){allCorrect = false;}

        //If everything is correct un border and go to next phase
        if(allCorrect){
            mergeProgress++;
            for(int i = 0; i < 16; i++) {
               if((i >= 3 && i <= 6) || (i >= 9 && i <= 12)){
                   mergeList[2][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
               }
            }
        }else{
            //show incorrect message
            ui->IncorrectMergeLabel->setVisible(true);
        }
    }
    //If in the third stage of merging show correct places
    else if(mergeProgress == 3){
        bool done = true;
        for(int i = 0; i < 16; i++) {
            if(i > 3 && i < 12){
                mergeList[3][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px; border-width: 5px; border-style: solid;");
                if(mergeList[3][i]->text().toStdString() == ""){done = false;}
            }
        }
        if(!done){return;}

        //Check that values are in the correct location
        bool allCorrect = true;
        for(int i = 0; i < 16; i++) {
            if(i > 3 && i < 12){
                if(i == 11){continue;}
                if(mergeList[3][i]->text().toInt() >= mergeList[3][i+1]->text().toInt()){allCorrect = false;}
            }
        }

        //If all correct un border and finish
        if(allCorrect){
            mergeProgress++;
            for(int i = 0; i < 16; i++) {
                if(i > 3 && i < 12){
                    mergeList[3][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
                }
            }
        }else{
            ui->IncorrectMergeLabel->setVisible(true);
        }
    }else{
        //Emit complete and show message
        ui->CorrectMergeLabel->setVisible(true);
        emit complete();
    }
}

/**
 * @brief MergePractice::partitionPhase - partition phase logic of the program. Shows correct containers at correct time
 */
void MergePractice::partitionPhase(){
    //Parition 1
    if(mouseY == 250){
        if(mouseX == 7){
            //Show partition 1 containers
            for(int i = 0; i < 16; i++) {
               if((i >= 3 && i <= 6) || (i >= 9 && i <= 12)){
                   partList[1][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
               }
            }
            //If finished go down a row
            mouseY += 95;
        }
        else{
            ui->IncorrectPartitionLabel->setVisible(true);
        }
    }

    //Parition 2
    else if(mouseY == 345){
        if(mouseX == 4){
            //Show partition 2 containers on left
            for(int i = 0; i < 8; i++) {
               if((i >= 2 && i <= 3) || (i >= 5 && i <= 6)){
                   partList[2][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
               }
            }
            p2Progress++;
        }else if(mouseX == 10){
            //Show partition 2 containers on right
            for(int i = 8; i < 16; i++) {
               if((i >= 9 && i <= 10) || (i >= 12 && i <= 13)){
                   partList[2][i]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
               }
            }
            p2Progress++;
        }
        else{
            //Show if incorrect location to partition
            ui->IncorrectPartitionLabel->setVisible(true);
        }

        //If finished go down a row
        if(p2Progress == 2){
            mouseY += 95;
        }
    }

    //Last partition into indvidual elements at each location
    else{
        if(mouseX == 2){
            partList[3][mouseX - 1]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
            partList[3][mouseX + 1]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
            p3Progress++;
        }else if(mouseX == 5){
            partList[3][mouseX]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
            partList[3][mouseX + 2]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px;font-size: 36px;" );
            p3Progress++;
        }else if(mouseX == 9){
            partList[3][mouseX - 1]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
            partList[3][mouseX + 1]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
            p3Progress++;
        }else if(mouseX == 12){
            partList[3][mouseX]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
            partList[3][mouseX + 2]->setStyleSheet("background-color:rgb(35, 84, 144); border-radius: 25px; font-size: 36px;");
            p3Progress++;
        }else{
            ui->IncorrectPartitionLabel->setVisible(true);
        }

        //If all partitions are correct show congrats message and emit completion
        if(p3Progress == 4){
            mergePhaseStarted = true;
            ui->CorrectPartitionLabel->setVisible(true);
            ui->mergePhaseButton->setVisible(true);
        }

    }
}

