#ifndef NAVIGATIONWINDOW_H
#define NAVIGATIONWINDOW_H

#include "mainmodel.h"
#include <QWidget>

namespace Ui {
class NavigationWindow;
}

class NavigationWindow : public QWidget
{
    Q_OBJECT

public:
    explicit NavigationWindow(MainModel& model, QWidget *parent = nullptr);
    ~NavigationWindow();

private:
    //Fields
    Ui::NavigationWindow *ui;
    std::string selection;

    /**
     * @brief updateSelection - updates the selection of the windows. Moves between practices and learns
     */
    void updateSelection();

    /**
     * @brief setUpButtons - sets up the buttons to be on an off
     * @param completion - takes in an int for how much the user has completed
     */
    void setUpButtons(int completion);

signals:
    /**
     * @brief sendSelection - sends the section the user selected
     * @param val - the section name
     */
    void sendSelection(std::string val);

    /**
     * @brief sendAccess - sends to the model telling it to update the button access
     */
    void sendAccess();
};

#endif // NAVIGATIONWINDOW_H
