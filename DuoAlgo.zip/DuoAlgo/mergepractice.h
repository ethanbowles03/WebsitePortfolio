/**
 *
 * Practice class for merge sort
 * Allows the user to practice partitioning an unsorted array
 * and then allow them to practice merging the array together
 *
 */
#ifndef MERGEPRACTICE_H
#define MERGEPRACTICE_H

#include "QtWidgets/qlabel.h"
#include "mainmodel.h"

#include <QWidget>
#include <QMouseEvent>
#include <QTimer>
#include <QDrag>
#include <QGraphicsSceneMouseEvent>
#include <QGridLayout>

namespace Ui {
class MergePractice;
}

class MergePractice : public QWidget
{
    Q_OBJECT

public:
    /**
     * @brief MergePractice - constructor for the merge practice class
     * @param model - takes in a model to use for updates
     * @param parent - parent widget
     */
    explicit MergePractice(MainModel &model, QWidget *parent = nullptr);
    ~MergePractice();

private:
    //Fields
    Ui::MergePractice *ui;
    QTimer *mouseTimer;
    QLabel* partList[4][16];
    QLabel* mergeList[4][16];
    int backing[8] = {8,2,3,5,1,7,6,4};
    int mouseX;
    int mouseY = 250;
    int p2Progress = 0, p3Progress = 0;
    int mergeProgress = 1;
    bool mergePhaseStarted = false;

    /**
     * @brief populateGrid - populates all of the merge and partition containers in the grid
     */
    void populateGrid();

    /**
     * @brief mouseUpdate - updates the mouseX and mouseY every 1 milli second
     */
    void mouseUpdate();

    /**
     * @brief startMergePhase - signals to the program to start the merge phase
     */
    void startMergePhase();

    /**
     * @brief partitionPhase - runs the code for the partition phase logic
     */
    void partitionPhase();

    /**
     * @brief mergePhase - runs the code for the merge phase logic
     */
    void mergePhase();

signals:
    /**
     * @brief complete - signals the model that the merge learn phase is complete
     */
    void complete();

protected:
    /**
     * @brief mouseReleaseEvent - action on mouse release
     * @param event
     */
    void mouseReleaseEvent(QMouseEvent *event) override;

    /**
     * @brief mousePressEvent - action on mouse pressed
     * @param event
     */
    void mousePressEvent(QMouseEvent *event) override;
};

#endif // MERGEPRACTICE_H
