#include "elementcontainer.h"
/**
 * @brief ElementContainer::ElementContainer - constructor for the element container class
 * Is a QLabel
 * @param text - the text to put in the label
 * @param parent
 * @param f
 */
ElementContainer::ElementContainer(const QString &text, QWidget *parent, Qt::WindowFlags f) :
    QLabel(text, parent, f)
{
    setAcceptDrops(true);
    setStyleSheet("QLabel { background-color : #5D7798; color : #5D7798;}");
    setAlignment(Qt::AlignCenter);
}

/**
 * @brief ElementContainer destructor.
 */
ElementContainer::~ElementContainer(){}

/**
 * @brief Event for dragging a specified element.
 * @param event
 */
void ElementContainer::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasFormat("text/plain"))
        event->acceptProposedAction();
}

/**
 * @brief Event for dropping a specified element.
 * @param event
 */
void ElementContainer::dropEvent(QDropEvent *event){
      setText(event->mimeData()->text());
      event->acceptProposedAction();
}

