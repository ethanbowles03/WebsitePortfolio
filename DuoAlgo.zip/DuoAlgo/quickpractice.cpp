#include "quickpractice.h"
#include "ui_quickpractice.h"
#include "element.h"
#include <QBrush>
#include <iostream>

/**
 * @brief QuickPractice constructor
 * @param model
 * @param parent
 */
QuickPractice::QuickPractice(MainModel &model, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QuickPractice)
{
    ui->setupUi(this);
    ui->checkButton->setDisabled(true);
    ui->correctLabel->hide();
    ui->incorrectLabel->hide();
    ui->finishedLabel->hide();

    connect(ui->listWidget, &QListWidget::itemPressed, this, &QuickPractice::EnableCheckButton);
    connect(ui->checkButton, &QPushButton::clicked, this, &QuickPractice::CheckSolution);
    connect(this, &QuickPractice::stepComplete, this, &QuickPractice::SetUpNextStep);
    connect(this, &QuickPractice::stepIncomplete, this, &QuickPractice::ContinueCurrentStep);
    connect(this, &QuickPractice::orderingComplete, this, &QuickPractice::DisplayComplete);
    connect(this, &QuickPractice::complete, &model, &MainModel::onUpdateAccess);


    // Starting-state of the elements
    int start[10] = {1, 7, 3, 5, 4, 6, 8, 9, 2, 0};
    setState(start);
    stepCounter = 0;

    QListWidgetItem* item = ui->listWidget->item(4);
    Element* e = dynamic_cast<Element*>(ui->listWidget->itemWidget(item));
    if(stepCounter == 0){e->highlight();}
}

/**
 * @brief QuickPractice destructor
 */
QuickPractice::~QuickPractice()
{
    delete ui;
}

/**
 * @brief Sets the state of the elements in the list
 * @param state - an array that describes the state of the elements in order
 */
void QuickPractice::setState(int state[]){
    // Clear out the list
    while(ui->listWidget->count() > 0) {
        ui->listWidget->takeItem(0);
    }

    // Generate all of the elements and store in temp vector
    QVector<Element*> temp;
    for(int i = 0; i < 10; i++) {
        Element* e = new Element(this, i);
        temp.append(e);
    }

    // Get the size of elements
    Element e;
    QSize elementSize(e.width(), e.height());

    // Add in each element to the correct index
    for(int i = 0; i < 10; i++) {
        // Create a new item to pair with the widget
        QListWidgetItem* item = new QListWidgetItem();
        item->setSizeHint(elementSize);

        // Translate the current index to "shuffle" the elements according to the start array
        int index = state[i];
        Element* e = temp[index];

        // Add the item-widget pair to the list
        ui->listWidget->addItem(item);
        ui->listWidget->setItemWidget(item, e);
    }
}

/**
 * @brief Enables check button
 */
void QuickPractice::EnableCheckButton(){
    ui->correctLabel->hide();
    ui->incorrectLabel->hide();
    ui->checkButton->setEnabled(true);
}

/**
 * @brief Checkes to make sure the user's order is correct in the exercise.
 */
void QuickPractice::CheckSolution(){
    int currentOrder[10];
    //populates currentOrder list
    for(int i = 0; i < 10; i++) {
        QListWidgetItem* item = ui->listWidget->item(i);
        Element* e = dynamic_cast<Element*>(ui->listWidget->itemWidget(item));
        currentOrder[i] = e->number;
    }

    //creates lists checking for each step
    int step1[] = { 1, 7, 3, 5, 0, 6, 8, 9, 2, 4};
    int step2[] = { 1, 2, 3, 5, 0, 6, 8, 9, 7, 4};
    int step3[] = { 1, 2, 3, 0, 5, 6, 8, 9, 7, 4};
    int step4[] = { 1, 2, 3, 0, 4, 6, 8, 9, 7, 5};
    int step5[] = { 1, 0, 3, 2, 4, 6, 8, 9, 7, 5};
    int step6[] = { 1, 0, 2, 3, 4, 6, 8, 9, 7, 5};
    int step7[] = { 0, 1, 2, 3, 4, 6, 8, 9, 7, 5};
    int step8[] = { 0, 1, 2, 3, 4, 6, 8, 5, 7, 9};
    int step9[] = { 0, 1, 2, 3, 4, 6, 7, 5, 8, 9};
    int step10[] = { 0, 1, 2, 3, 4, 6, 5, 7, 8, 9};
    int step11[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9};


    //assigns the step lists into a vector of lists
    std::vector checkList = {step1, step2, step3, step4, step5, step6, step7, step8, step9, step10, step11};

    //if the currentOrder list is not in the correct order, emits stepIncomplete
    for(int i = 0; i < 10; i++){
        if (currentOrder[i] != checkList[stepCounter][i]){
            emit stepIncomplete();
            return;
        }
    }

    //if statements calling private helper method to highlight and unhighlight old and new pivots
    if(stepCounter == 3){
        QuickPractice::highlightSelector(4,1);
    }else if(stepCounter == 5){
        QuickPractice::highlightSelector(2,1);
    }else if(stepCounter == 6){
        QuickPractice::highlightSelector(0,7);
    }else if(stepCounter == 8){
        QuickPractice::highlightSelector(9,6);
    }else if(stepCounter == 9){
        QuickPractice::highlightSelector(7,6);
    }
    //if it is the final step, emits orderingComplete
    else if(stepCounter == 10)
        emit orderingComplete();
    emit stepComplete();
}

/**
 * @brief Private helper method that highlights the new pivot item and unhighlights the old pivot itme
 * @param oldPivot int index of the old pivot item
 * @param newPivot int index of the new pivot item
 */
void QuickPractice::highlightSelector(int oldPivot, int newPivot){
    QListWidgetItem* item = ui->listWidget->item(newPivot);
    Element* e = dynamic_cast<Element*>(ui->listWidget->itemWidget(item));
    QListWidgetItem* oldPivotItem = ui->listWidget->item(oldPivot);
    Element* oldE = dynamic_cast<Element*>(ui->listWidget->itemWidget(oldPivotItem));
    oldE->removeHighlight();
    e->highlight();
}

/**
 * @brief After correctly finishing a step, sets the ui up for the next step
 */
void QuickPractice::SetUpNextStep(){
    ui->correctLabel->show();
    ui->checkButton->setDisabled(true);
    stepCounter++;
}

/**
 * @brief After incorrectly attempting a step, sets the ui up to continue the current step
 */
void QuickPractice::ContinueCurrentStep(){
    ui->incorrectLabel->show();
    ui->checkButton->setDisabled(true);
}

/**
 * @brief After correctly finishing the algorithm, disables ui forcing user to return to home
 */
void QuickPractice::DisplayComplete(){
    ui->finishedLabel->show();
    ui->checkButton->setDisabled(true);
    ui->listWidget->setDisabled(true);
    emit complete();
}
