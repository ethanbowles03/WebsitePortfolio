#ifndef QUIZ_H
#define QUIZ_H

#include "mainmodel.h"
#include <QWidget>

namespace Ui {
class Quiz;
}

class Quiz : public QWidget
{
    Q_OBJECT

public:
    explicit Quiz(MainModel &model, QWidget *parent = nullptr);
    ~Quiz();

    // A struct to hold each quiz question
    struct QuizQuestion {
        QString question;
        QVector<QString> answers;
        int correctAnswerIndex;
    };

private:
    Ui::Quiz *ui;

    // Push button stylings
    const QString buttonStyling = "background-color: #fff; color: #235490; font-size: 14px; border-radius: 1px; min-height: 40px;";
    const QString buttonStylingClicked = "background-color: #235490; color: #fff; font-size: 14px; border-radius: 1px; min-height: 40px;";
    const QString buttonStylingDisabled = "background-color: #ccc; color: #235490; font-size: 14px; border-radius: 1px; min-height: 40px;";

    // All of the quiz questions
    QVector<QuizQuestion> questions;

    // Index of current question being displayed
    int currentQuestionIndex;

    // Reads in questions from a file
    QVector<QuizQuestion> readQuizQuestionsFromFile(QString filename);

    // Displays the question in the view
    void displayQuestion(int index);

    // Called whenever one of the 4 answers are clicked and checks correctness
    void answerClicked(int answer);

    // "Highlights" button, and then disables other buttons. (Or resets if -1 is passed in)
    void changeButtonStylings(int button);

    // Called when the next button is pressed. Shows the next question.
    void nextQuestion();

signals:
    void complete();
};

#endif // QUIZ_H
